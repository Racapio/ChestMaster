package com.chestmaster.mixin;

import com.chestmaster.ChestMasterMod;
import com.chestmaster.scanner.ChestScanner;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_2561;
import net.minecraft.class_465;
import net.minecraft.class_476;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_476.class)
public abstract class GenericContainerScreenMixin {
    @Inject(method = "<init>", at = @At("TAIL"))
    private void onInit(class_1707 handler, class_1661 inventory, class_2561 title, CallbackInfo ci) {
        if (!ChestScanner.INSTANCE.isAutoScanEnabled()) {
            return;
        }

        try {
            if (ChestMasterMod.Companion.isVerboseLogging()) {
                ChestMasterMod.Companion.getLOGGER().debug("Container opened: " + title.getString());
            }
            ChestScanner.INSTANCE.onScreenOpen((class_465<?>)(Object)this, handler);
        } catch (Exception e) {
            ChestMasterMod.Companion.getLOGGER().error("Error in ChestScanner.onScreenOpen", e);
        }
    }
}
